# SmartHire - Przykłady diagramów w Mermaid

Poniżej znajdują się przykłady kodu w języku Mermaid, które można wykorzystać do generowania diagramów dla aplikacji SmartHire. Kod można wkleić do edytora Mermaid (np. [Mermaid Live Editor](https://mermaid.live/)) lub użyć w dokumentacji Markdown (np. GitHub, GitLab).

## 1. Diagram wysokopoziomowy

```mermaid
flowchart TD
    %% Definicja stylów
    classDef user fill:#1589EE,color:white,stroke:#0070D2,stroke-width:2px
    classDef ui fill:#1589EE,color:white
    classDef logic fill:#4CAF50,color:white
    classDef data fill:#FF9800,color:white
    classDef external fill:#F44336,color:white
    
    %% Użytkownicy
    U1[Rekruter] --> P1
    U2[Menedżer HR] --> P1
    U3[Menedżer zatrudniający] --> P1
    
    %% Główne komponenty
    P1[Portal rekrutacyjny] --> E1
    P1 --> S1
    
    E1[Silnik analizy CV] --> API
    E1 --> S1
    
    S1[System zarządzania kandydatami] --> DB
    
    %% Integracje zewnętrzne
    API[OpenAI API]
    DB[(Baza danych Salesforce)]
    
    %% Przypisanie klas
    class U1,U2,U3 user
    class P1 ui
    class E1,S1 logic
    class DB data
    class API external
```

## 2. Diagram przepływu pracy (workflow)

```mermaid
flowchart TD
    %% Definicja stylów
    classDef rekruter fill:#1589EE,color:white
    classDef system fill:#9C27B0,color:white
    classDef menedzerHR fill:#4CAF50,color:white
    
    %% Proces rekrutera
    R1[Dodanie nowej aplikacji i CV] -->|Inicjacja| R2[Uruchomienie analizy CV]
    R2 --> S1
    S2 --> R3[Przegląd wyników analizy]
    R3 --> R4{Czy kandydat spełnia\npodstawowe wymagania?}
    R4 -->|Tak| R5[Wstępna ocena kandydata]
    R4 -->|Nie| R10[Odrzucenie kandydata]
    
    %% Proces systemu
    S1[Asynchroniczne przetwarzanie CV] -->|ResumeAnalysisQueueable| S1a[Wywołanie OpenAI API]
    S1a --> S1b[Analiza i ekstrakcja danych]
    S1b --> S2[Aktualizacja statusu aplikacji]
    
    %% Przypisanie klas
    class R1,R2,R3,R4,R5,R10 rekruter
    class S1,S1a,S1b,S2 system
```

## 3. Diagram modelu danych (ERD)

```mermaid
erDiagram
    Application__c ||--o{ Candidate__c : "ma"
    Application__c ||--o{ Position__c : "dotyczy"
    
    Application__c {
        Id id PK
        Reference Candidate__c FK
        Reference Position__c FK
        Picklist Status__c
        Text Resume__c
        Date Application_Date__c
    }
    
    Position__c {
        Id id PK
        Text Title__c
        TextArea Description__c
        Text Required_Skills__c
    }
    
    Candidate__c {
        Id id PK
        Text First_Name__c
        Text Last_Name__c
        Email Email__c
        Text Skills__c
    }
```

## 4. Diagram sekwencji dla procesu analizy CV

```mermaid
sequenceDiagram
    actor Rekruter
    participant UI as cvAnalyzer LWC
    participant Controller as CVAnalysisController
    participant Service as CVAnalysisService
    participant OpenAI as OpenAIService
    
    Rekruter->>UI: Dodaje CV kandydata
    UI->>Controller: handleFileUpload()
    Controller->>Service: analyzeResume(resumeId)
    Service->>OpenAI: sendForAnalysis(resumeText)
    OpenAI-->>Service: Zwraca wyniki analizy
    Service-->>Controller: Zwraca wyniki analizy
    Controller-->>UI: Przekazuje wyniki analizy
    UI->>Rekruter: Wyświetla wyniki analizy
```

## Jak używać tych diagramów

1. Skopiuj kod diagramu, który chcesz wygenerować
2. Wklej go do edytora Mermaid (np. [Mermaid Live Editor](https://mermaid.live/))
3. Dostosuj diagram do swoich potrzeb
4. Wyeksportuj diagram jako obraz (PNG, SVG) lub osadź kod w dokumentacji Markdown